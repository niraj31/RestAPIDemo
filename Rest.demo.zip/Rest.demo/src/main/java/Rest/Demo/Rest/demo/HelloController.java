package Rest.Demo.Rest.demo;

import org.springframework.context.annotation.*;
import org.springframework.web.bind.annotation.*;

@Configuration
@RestController
public class HelloController {

	
	@GetMapping(path="/hello-world")
	public String helloWorld() {
		return "Hello World";
	}
	
	@GetMapping(path="/hello-world-bean")
	public HelloBean helloBean1() {
		return new HelloBean("Hello World");
	}
	
	@GetMapping(path="/hello-world/path-variable/{name}")
	public HelloBean helloBean(@PathVariable String name) {
		return new HelloBean(String.format("Hello World,%s", name));
	}
}

package Rest.Demo.Rest.demo;

public class HelloBean {
	public String message;
	public HelloBean(String message) {
		this.message=message;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String toString() {
		return String.format("Hello World Bean [message=%s]", message);
	}
}

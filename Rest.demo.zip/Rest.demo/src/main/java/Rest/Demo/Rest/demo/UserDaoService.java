package Rest.Demo.Rest.demo;
import java.util.*;
import org.springframework.stereotype.*;

@Component
public class UserDaoService {
	public static int userCount=5;
	
	private static List<User> users=new ArrayList<>();
	static {
		users.add(new User(1, "Aditya",new Date()));
		users.add(new User(2, "Vidhi",new Date()));
		users.add(new User(3, "Shreya",new Date()));
		users.add(new User(4, "Vijeet",new Date()));
		users.add(new User(5, "Sheela",new Date()));
	}
	public List<User> findAll(){
		return users;
	}
	
	public User save(User user) {
		if(user.getId()==0) {
			user.setId(++userCount);
		}
		users.add(user);
		return user;
	}
	public User findOne(int id) {
		for(User user:users) {
			if(user.getId()==id) {
				return user;
			}
		}
		return null;
	}
}